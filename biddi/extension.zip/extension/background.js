// BodyCart - Background Service Worker

// Extension installed
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('BodyCart extension installed');
  } else if (details.reason === 'update') {
    console.log('BodyCart extension updated');
  }
});

// Function to extract seller data from seller profile page
function extractSellerDataFromPage() {
  const allSpans = Array.from(document.querySelectorAll('span'));
  const data = {
    name: null,
    join_date: null,
    listings_count: null,
    followers_count: null,
    location: null,
    ratings_count: null,
    ratings_average: null,
    badges: [],
    strengths: [],
    profile_screenshot: null
  };

  // Extract seller name (usually h1 or prominent heading)
  const h1 = document.querySelector('h1');
  if (h1) {
    data.name = h1.textContent.trim();
  }

  for (const span of allSpans) {
    const text = span.textContent.trim();

    // Join date: "Se unió a Facebook en 2008"
    if (/se\s+unió\s+a?\s*facebook\s+(en\s+)?\d{4}/i.test(text)) {
      data.join_date = text;
    }

    // Listings count: "20+ publicaciones activas"
    const listingsMatch = text.match(/(\d+)\+?\s*(publicaciones?|listings?)/i);
    if (listingsMatch) {
      data.listings_count = listingsMatch[1] + '+';
    }

    // Followers: "76 seguidores"
    const followersMatch = text.match(/(\d+)\s*(seguidores|followers)/i);
    if (followersMatch) {
      data.followers_count = parseInt(followersMatch[1]);
    }

    // Location: "Vive en Santiago de Chile"
    const locationMatch = text.match(/vive\s+en\s+(.+)/i);
    if (locationMatch) {
      data.location = locationMatch[1];
    }

    // Ratings count: "Según 22 calificaciones"
    const ratingsMatch = text.match(/(\d+)\s*(calificaciones?|ratings?|reviews?)/i);
    if (ratingsMatch) {
      data.ratings_count = parseInt(ratingsMatch[1]);
    }

    // Badges: "Buena calificación"
    if (/buena\s+calificaci[oó]n/i.test(text)) {
      data.badges.push('Buena calificación');
    }
    if (/vendedor\s+(destacado|top)/i.test(text)) {
      data.badges.push('Vendedor destacado');
    }
    if (/responde\s+r[aá]pido/i.test(text)) {
      data.badges.push('Responde rápido');
    }

    // Strengths: "Comunicación (13)", "Puntualidad (5)"
    const strengthMatch = text.match(/(comunicaci[oó]n|puntualidad|descripci[oó]n|precio)\s*\((\d+)\)/i);
    if (strengthMatch) {
      data.strengths.push(`${strengthMatch[1]} (${strengthMatch[2]})`);
    }
  }

  // Try to calculate average rating from stars
  const starsContainer = document.querySelector('[aria-label*="estrella"], [aria-label*="star"]');
  if (starsContainer) {
    const ariaLabel = starsContainer.getAttribute('aria-label');
    const ratingMatch = ariaLabel?.match(/(\d+[.,]?\d*)/);
    if (ratingMatch) {
      data.ratings_average = parseFloat(ratingMatch[1].replace(',', '.'));
    }
  }

  // Count filled stars visually
  const allStars = document.querySelectorAll('svg[aria-label*="estrella"], i[class*="star"]');
  if (allStars.length > 0 && !data.ratings_average) {
    // Heuristic: count orange/filled stars
    data.ratings_average = allStars.length;
  }

  console.log('[BodyCart] Seller data extracted:', data);
  return data;
}

// Extract seller profile in a hidden tab
async function extractSellerProfile(sellerUrl) {
  return new Promise((resolve) => {
    // Create hidden tab
    chrome.tabs.create({
      url: sellerUrl,
      active: false // Don't focus the tab
    }, (tab) => {
      const tabId = tab.id;
      let resolved = false;

      // Timeout after 10 seconds
      const timeout = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          chrome.tabs.remove(tabId).catch(() => {});
          resolve({ error: 'Timeout loading seller profile' });
        }
      }, 10000);

      // Listen for tab to finish loading
      const onUpdated = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);

          // Wait a bit for React to hydrate
          setTimeout(async () => {
            if (resolved) return;

            try {
              // Capture screenshot of seller profile
              let screenshot = null;
              try {
                const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png', quality: 80 });
                screenshot = dataUrl.split(',')[1];
              } catch (e) {
                console.log('[BodyCart] Could not capture seller screenshot:', e);
              }

              // Inject and execute extraction script
              const results = await chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: extractSellerDataFromPage
              });

              clearTimeout(timeout);
              resolved = true;

              // Close the tab
              chrome.tabs.remove(tabId).catch(() => {});

              if (results && results[0]?.result) {
                const sellerData = results[0].result;
                sellerData.profile_screenshot = screenshot;
                resolve(sellerData);
              } else {
                resolve({ error: 'No data extracted' });
              }
            } catch (error) {
              clearTimeout(timeout);
              resolved = true;
              chrome.tabs.remove(tabId).catch(() => {});
              resolve({ error: error.message });
            }
          }, 2000); // Wait 2s for content to load
        }
      };

      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  });
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CAPTURE_SCREENSHOT') {
    // Capture visible tab as base64
    chrome.tabs.captureVisibleTab(
      null,
      { format: 'png', quality: 80 },
      (dataUrl) => {
        if (chrome.runtime.lastError) {
          console.error('Screenshot error:', chrome.runtime.lastError);
          sendResponse({ screenshot: null });
        } else {
          // Extract base64 data (remove "data:image/png;base64," prefix)
          const base64 = dataUrl.split(',')[1];
          sendResponse({ screenshot: base64 });
        }
      }
    );
    // Return true to indicate async response
    return true;
  }

  if (message.type === 'EXTRACT_SELLER_PROFILE') {
    // Extract seller data from profile page in background tab
    extractSellerProfile(message.url)
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ error: error.message });
      });
    return true; // Async response
  }

  if (message.type === 'ANALYZE_PAGE') {
    // Future: Additional background processing if needed
    sendResponse({ status: 'received', data: message.data });
  }

  return true;
});
