// Page Analyzer - Content Script
(function () {
  "use strict";

  // Prevent multiple injections
  if (window.__pageAnalyzerInitialized) return;
  window.__pageAnalyzerInitialized = true;

  // Configuration - Change this to your deployed backend URL
  // const API_URL = 'https://backend-muddy-silence-3898.fly.dev';
  const API_URL = "http://localhost:8000";

  // Platform detection
  function detectPlatform() {
    const url = window.location.href;
    const hostname = window.location.hostname;

    if (hostname.includes("facebook.com") && url.includes("/marketplace/item/")) {
      return "facebook_marketplace";
    }
    // Add more platforms here as needed
    return "ecommerce";
  }

  // ============================================
  // PROGRESS UI FUNCTIONS
  // ============================================

  const PROGRESS_STEPS = [
    { id: 'scroll', text: 'Cargando detalles del producto' },
    { id: 'screenshot', text: 'Capturando imagen' },
    { id: 'extract', text: 'Extrayendo información' },
    { id: 'seller', text: 'Investigando perfil del vendedor' },
    { id: 'analyze', text: 'Analizando con IA' }
  ];

  function renderProgressUI(currentStepIndex = 0) {
    const stepsHtml = PROGRESS_STEPS.map((step, index) => {
      let status = 'pending';
      let icon = `${index + 1}`;

      if (index < currentStepIndex) {
        status = 'completed';
        icon = '✓';
      } else if (index === currentStepIndex) {
        status = 'active';
        icon = '●';
      }

      return `
        <div class="pa-progress-step ${status}" data-step="${step.id}">
          <div class="pa-step-icon">${icon}</div>
          <div class="pa-step-text">${step.text}</div>
        </div>
      `;
    }).join('');

    return `
      <div class="pa-progress-container">
        <div class="pa-progress-title">Investigando publicación...</div>
        <div class="pa-progress-steps">
          ${stepsHtml}
        </div>
        <div class="pa-progress-time">Tiempo estimado: 10-15 segundos</div>
      </div>
    `;
  }

  function updateProgressStep(stepIndex) {
    const content = document.getElementById('pa-content');
    if (content) {
      content.innerHTML = renderProgressUI(stepIndex);
    }
  }

  // ============================================
  // SILENT SCROLL FUNCTION
  // ============================================

  async function silentScroll() {
    // Find the main scroll container (Facebook uses various containers)
    const scrollContainers = [
      document.querySelector('[role="main"]'),
      document.querySelector('.x1n2onr6'), // Facebook's common scroll container class
      document.documentElement,
      document.body
    ];

    let scrollContainer = null;
    for (const container of scrollContainers) {
      if (container && container.scrollHeight > container.clientHeight) {
        scrollContainer = container;
        break;
      }
    }

    if (!scrollContainer) {
      scrollContainer = document.documentElement;
    }

    // Save original scroll position
    const originalScrollTop = scrollContainer.scrollTop || window.scrollY;

    // Scroll down to trigger lazy loading
    const scrollStep = 500;
    const maxScrolls = 10;
    let scrollCount = 0;

    while (scrollCount < maxScrolls) {
      const prevHeight = scrollContainer.scrollHeight;

      // Scroll down
      if (scrollContainer === document.documentElement) {
        window.scrollTo({ top: window.scrollY + scrollStep, behavior: 'instant' });
      } else {
        scrollContainer.scrollTop += scrollStep;
      }

      // Wait for content to load
      await new Promise(r => setTimeout(r, 200));

      // Check if we've reached the bottom or content stopped growing
      const atBottom = (scrollContainer === document.documentElement)
        ? (window.innerHeight + window.scrollY >= document.body.scrollHeight - 100)
        : (scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight - 100);

      if (atBottom || scrollContainer.scrollHeight === prevHeight) {
        break;
      }

      scrollCount++;
    }

    // Return to original position so user doesn't notice
    await new Promise(r => setTimeout(r, 100));
    if (scrollContainer === document.documentElement) {
      window.scrollTo({ top: originalScrollTop, behavior: 'instant' });
    } else {
      scrollContainer.scrollTop = originalScrollTop;
    }

    console.log('[BodyCart] Silent scroll completed');
  }

  // ============================================
  // SELLER PROFILE EXTRACTION (via background)
  // ============================================

  async function extractSellerProfileFromBackground(sellerUrl) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: 'EXTRACT_SELLER_PROFILE', url: sellerUrl },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[BodyCart] Seller extraction error:', chrome.runtime.lastError);
            resolve(null);
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  // ============================================
  // DEEP INVESTIGATION FLOW
  // ============================================

  async function deepInvestigateMarketplace() {
    console.log('[BodyCart] Starting deep investigation...');

    // Step 1: Silent scroll to load all content
    updateProgressStep(0);
    await silentScroll();
    await new Promise(r => setTimeout(r, 500));

    // Step 2: Capture screenshot
    updateProgressStep(1);
    const screenshot = await captureScreenshot();

    // Step 3: Extract listing data
    updateProgressStep(2);
    await new Promise(r => setTimeout(r, 1000)); // Wait for any dynamic content
    const listingData = await collectMarketplaceDataInternal();

    // Step 4: Extract seller profile (if URL available)
    updateProgressStep(3);
    let sellerProfileData = null;

    if (listingData.seller?.profile_url) {
      console.log('[BodyCart] Fetching seller profile:', listingData.seller.profile_url);
      sellerProfileData = await extractSellerProfileFromBackground(listingData.seller.profile_url);

      if (sellerProfileData && !sellerProfileData.error) {
        // Merge seller data
        listingData.seller = {
          ...listingData.seller,
          ...sellerProfileData,
          // Keep original profile_url
          profile_url: listingData.seller.profile_url
        };
      }
    }

    // Add screenshot to data
    listingData.screenshot_base64 = screenshot;

    console.log('[BodyCart] Deep investigation complete:', listingData);
    return listingData;
  }

  // Internal marketplace data collection (without screenshot)
  async function collectMarketplaceDataInternal() {
    // This is the same as collectMarketplaceData but without screenshot capture
    // (screenshot is handled separately in the flow)

    const getText = (selector) => {
      const el = document.querySelector(selector);
      return el ? el.textContent.trim() : null;
    };

    const allSpans = Array.from(document.querySelectorAll("span"));
    const allDivs = Array.from(document.querySelectorAll("div"));

    // ... Rest of extraction logic (price, title, etc.) - reuse from collectMarketplaceData
    // For now, call the existing function and just remove screenshot
    const data = await collectMarketplaceData();
    delete data.screenshot_base64; // Will be added later
    return data;
  }

  // Create floating button
  function createButton() {
    const button = document.createElement("button");
    button.id = "page-analyzer-btn";
    button.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="8"/>
        <path d="M21 21l-4.35-4.35"/>
      </svg>
    `;
    button.title = "BodyCart - Analizar Página";
    document.body.appendChild(button);
    return button;
  }

  // Create side panel
  function createSidePanel() {
    const panel = document.createElement("div");
    panel.id = "page-analyzer-panel";
    panel.innerHTML = `
      <div class="pa-panel-header">
        <h2>BodyCart - Análisis</h2>
        <button id="pa-close-btn" title="Close">&times;</button>
      </div>
      <div class="pa-panel-content" id="pa-content">
        <p class="pa-loading">Click en el botón de analizar para escanear esta página...</p>
      </div>
    `;
    document.body.appendChild(panel);
    return panel;
  }

  // Collect comprehensive page data for AI analysis
  async function collectPageData() {
    const scripts = Array.from(document.getElementsByTagName("script"));
    const externalScripts = scripts.filter(
      (s) => s.src && !s.src.startsWith(window.location.origin)
    ).length;

    const forms = Array.from(document.getElementsByTagName("form"));
    const formData = forms.map((f) => ({
      action: f.action || "none",
      method: f.method || "get",
      hasPasswordField: f.querySelector('input[type="password"]') !== null,
    }));

    const iframes = Array.from(document.getElementsByTagName("iframe"));
    const iframeData = iframes.map((f) => f.src || "no-src");

    // Capture screenshot
    const screenshot = await captureScreenshot();

    const pageData = {
      // Core fields as per backend requirements
      url: window.location.href,
      html_content: document.documentElement.outerHTML,
      screenshot_base64: screenshot,

      // Additional metadata
      title: document.title || "No title",
      metaDescription: getMetaContent("description"),
      metaKeywords: getMetaContent("keywords"),
      scripts: scripts.length,
      externalScripts: externalScripts,
      links: analyzeLinks(),
      images: document.getElementsByTagName("img").length,
      loadTime: Math.round(performance.now()) + "ms",
      charset: document.characterSet,
      language: document.documentElement.lang || "Not specified",
      forms: formData.length > 0 ? JSON.stringify(formData) : "No forms",
      iframes:
        iframeData.length > 0 ? JSON.stringify(iframeData) : "No iframes",
      protocol: window.location.protocol,
    };

    console.log("[Page Analyzer] Scraping complete:", pageData);
    return pageData;
  }

  // Collect Facebook Marketplace specific data
  async function collectMarketplaceData() {
    // Wait for dynamic content to load (Facebook is a React SPA)
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const screenshot = await captureScreenshot();

    // Helper to safely get text content
    const getText = (selector) => {
      const el = document.querySelector(selector);
      return el ? el.textContent.trim() : null;
    };

    // Get all text elements for pattern matching
    const allSpans = Array.from(document.querySelectorAll("span"));
    const allDivs = Array.from(document.querySelectorAll("div"));

    // ============================================
    // PRICE DETECTION - Multiple formats
    // ============================================
    let price = null;

    // Price patterns to match
    const pricePatterns = [
      /^[\d\s.,]+\s*\$\s*·?\s*(disponible)?$/i,  // 35 000 $ · Disponible or 35 000 $
      /^\$\s*[\d\s.,]+$/,                         // $1,500 or $ 1 500
      /^[\d\s.,]+\s*\$$/,                         // 90 000 $ (Chilean format)
      /^[\d\s.,]+\s*(USD|MXN|CLP|EUR|pesos?)$/i,  // 1500 USD or 1500 pesos
      /^(gratis|free)$/i,                         // Free
      /^[\d,.]+\s*€$/,                            // European format
    ];

    for (const span of allSpans) {
      const text = span.textContent.trim();
      // Skip very long text (not a price) or very short
      if (text.length > 30 || text.length < 1) continue;

      for (const pattern of pricePatterns) {
        if (pattern.test(text)) {
          // Clean up the price - remove "· Disponible" suffix
          price = text.replace(/\s*·\s*(disponible|available).*$/i, '').trim();
          break;
        }
      }
      if (price) break;
    }

    // ============================================
    // TITLE DETECTION
    // ============================================
    let title = null;

    // Excluded title patterns (UI elements, not actual titles)
    const excludedTitlePatterns = [
      /resultados/i,
      /búsqueda/i,
      /search/i,
      /marketplace/i,
      /facebook/i,
      /enviar\s+mensaje/i,
      /detalles/i,
      /vendedor/i,
      /^\d+\s*(photos?|fotos?)/i,
    ];

    const isValidTitle = (text) => {
      if (!text || text.length < 3 || text.length > 150) return false;
      for (const pattern of excludedTitlePatterns) {
        if (pattern.test(text)) return false;
      }
      return true;
    };

    // Strategy 1: Look for h1
    const h1Text = getText("h1");
    if (isValidTitle(h1Text)) {
      title = h1Text;
    }

    // Strategy 2: Look for the main listing title in the right panel
    // Facebook's listing title is typically a prominent span early in the details section
    if (!title) {
      // Find spans that look like titles (substantial text, not too long)
      for (const span of allSpans) {
        const text = span.textContent.trim();
        const rect = span.getBoundingClientRect();

        // Title characteristics:
        // - In the right portion of screen (details panel)
        // - Near the top (but not at very top which is navigation)
        // - Reasonable length
        // - Not a price, not a UI element
        if (
          isValidTitle(text) &&
          rect.left > window.innerWidth * 0.5 &&
          rect.top > 50 && rect.top < 250 &&
          !/^\d/.test(text) && // Doesn't start with number (likely price)
          !/^\$/.test(text) && // Not a price
          !text.includes("·")  // Not price with status
        ) {
          title = text;
          break;
        }
      }
    }

    // Strategy 3: Fallback to document title (clean it up)
    if (!title) {
      let docTitle = document.title;
      // Remove common Facebook suffixes
      docTitle = docTitle
        .replace(/\s*[-|·]\s*Facebook.*$/i, '')
        .replace(/\s*[-|·]\s*Marketplace.*$/i, '')
        .replace(/Resultados de la búsqueda/i, '')
        .trim();

      if (isValidTitle(docTitle)) {
        title = docTitle;
      }
    }

    // Final fallback
    if (!title) {
      title = "Publicación de Marketplace";
    }

    // ============================================
    // POSTED DATE & LOCATION - Spanish and English
    // ============================================
    let postedDate = null;
    let listingLocation = null;

    for (const span of allSpans) {
      const text = span.textContent.trim();

      // Spanish: "Publicado hace 3 semanas en Santiago, RM"
      const spanishWithDateMatch = text.match(/publicado\s+hace\s+(.+?)\s+en\s+(.+)/i);
      if (spanishWithDateMatch) {
        postedDate = spanishWithDateMatch[1]; // "3 semanas"
        listingLocation = spanishWithDateMatch[2]; // "Santiago, RM"
        continue;
      }

      // Spanish without date: "Publicado en Quinta Normal, RM"
      const spanishLocationOnly = text.match(/publicado\s+en\s+(.+)/i);
      if (spanishLocationOnly && !listingLocation) {
        listingLocation = spanishLocationOnly[1];
        continue;
      }

      // English: "Listed 3 weeks ago in Miami, FL"
      const englishMatch = text.match(/listed\s+(.+?)\s+(?:ago\s+)?in\s+(.+)/i);
      if (englishMatch) {
        postedDate = englishMatch[1];
        listingLocation = englishMatch[2];
        continue;
      }

      // English location only: "Listed in Miami, FL"
      const englishLocationOnly = text.match(/listed\s+in\s+(.+)/i);
      if (englishLocationOnly && !listingLocation) {
        listingLocation = englishLocationOnly[1];
        continue;
      }

      // Time patterns (standalone)
      if (!postedDate) {
        // Spanish time patterns
        if (/hace\s+\d+\s+(día|días|semana|semanas|hora|horas|minuto|minutos|mes|meses)/i.test(text)) {
          postedDate = text;
        }
        // English time patterns
        if (/^\d+\s+(day|days|week|weeks|hour|hours|minute|minutes|month|months)s?\s+ago$/i.test(text)) {
          postedDate = text;
        }
        // "ayer" / "yesterday" / "hoy" / "today"
        if (/^(ayer|yesterday|hoy|today|just now|ahora)$/i.test(text)) {
          postedDate = text;
        }
      }
    }

    // ============================================
    // CONDITION - Spanish and English
    // ============================================
    let condition = null;
    const conditionTerms = [
      "new", "used - like new", "used - good", "used - fair", "used",
      "nuevo", "usado - como nuevo", "usado - buen estado", "usado - aceptable", "usado"
    ];

    for (const span of allSpans) {
      const text = span.textContent.trim().toLowerCase();
      if (conditionTerms.includes(text)) {
        condition = span.textContent.trim();
        break;
      }
    }

    // Also look for "Estado: Nuevo" pattern
    if (!condition) {
      for (const span of allSpans) {
        const text = span.textContent.trim();
        if (/^(estado|condition)\s*:?\s*/i.test(text)) {
          // The condition might be in a sibling element
          const parent = span.parentElement;
          if (parent) {
            const siblingText = parent.textContent.trim();
            const match = siblingText.match(/(nuevo|used|usado|like new|como nuevo|buen estado)/i);
            if (match) {
              condition = match[1];
              break;
            }
          }
        }
      }
    }

    // ============================================
    // DESCRIPTION - Look for the details section
    // ============================================
    let description = null;

    // Look for text after "Detalles" or "Details" heading
    for (let i = 0; i < allSpans.length; i++) {
      const span = allSpans[i];
      const text = span.textContent.trim().toLowerCase();
      if (text === "detalles" || text === "details") {
        // Get text from nearby elements
        const parent = span.closest("div");
        if (parent && parent.parentElement) {
          const containerText = parent.parentElement.textContent.trim();
          // Remove the "Detalles" header and extract description
          description = containerText.replace(/^(detalles|details)\s*/i, "").substring(0, 500);
          break;
        }
      }
    }

    // Fallback: look for longer text blocks
    if (!description) {
      const descCandidates = allDivs.filter((div) => {
        const text = div.textContent.trim();
        const children = div.children.length;
        // Look for divs with substantial text but not too nested
        return text.length > 30 && text.length < 1000 && children < 5;
      });

      if (descCandidates.length > 0) {
        // Sort by text length and get a reasonable one
        descCandidates.sort((a, b) => b.textContent.length - a.textContent.length);
        for (const candidate of descCandidates) {
          const text = candidate.textContent.trim();
          // Skip if it's just navigation or UI text
          if (!/^(marketplace|facebook|enviar|send|share)/i.test(text)) {
            description = text.substring(0, 500);
            break;
          }
        }
      }
    }

    // ============================================
    // SELLER INFO
    // ============================================
    let sellerName = null;
    let sellerJoinDate = null;
    let sellerProfileUrl = null;

    // Excluded seller name patterns (UI elements)
    const excludedSellerPatterns = [
      /detalles\s+del\s+vendedor/i,
      /seller\s+(details|info)/i,
      /ver\s+perfil/i,
      /view\s+profile/i,
      /marketplace/i,
      /enviar\s+mensaje/i,
      /send\s+message/i,
      /^\d+\s*(listings?|publicaciones?)/i,
    ];

    const isValidSellerName = (name) => {
      if (!name || name.length < 2 || name.length > 60) return false;
      for (const pattern of excludedSellerPatterns) {
        if (pattern.test(name)) return false;
      }
      // Should not be all caps UI text
      if (name === name.toUpperCase() && name.length > 10) return false;
      return true;
    };

    // Find seller profile links
    const profileLinks = Array.from(document.querySelectorAll('a[href*="/marketplace/profile/"], a[href*="/user/"], a[href*="facebook.com/"][role="link"]'));
    for (const link of profileLinks) {
      const name = link.textContent.trim();
      if (isValidSellerName(name)) {
        sellerName = name;
        sellerProfileUrl = link.href;
        break;
      }
    }

    // If no seller name found in links, look for it near "Seller" or "Vendedor" text
    if (!sellerName) {
      for (let i = 0; i < allSpans.length; i++) {
        const span = allSpans[i];
        const text = span.textContent.trim().toLowerCase();

        // Found seller section header, look at next siblings
        if (text === 'vendedor' || text === 'seller' || text.includes('detalles del vendedor')) {
          // Look at nearby elements for the actual name
          const parent = span.closest('div');
          if (parent && parent.parentElement) {
            const container = parent.parentElement;
            const links = container.querySelectorAll('a');
            for (const link of links) {
              const linkText = link.textContent.trim();
              if (isValidSellerName(linkText)) {
                sellerName = linkText;
                sellerProfileUrl = link.href;
                break;
              }
            }
          }
        }
        if (sellerName) break;
      }
    }

    // Look for join date - Spanish and English
    for (const span of allSpans) {
      const text = span.textContent.trim();
      // Spanish: "Se unió en 2019" or "Miembro desde 2019"
      // English: "Joined in 2019" or "Member since 2019"
      if (/^(se\s+unió|joined|miembro\s+desde|member\s+since)\s+(en\s+|in\s+)?\d{4}/i.test(text)) {
        sellerJoinDate = text;
        break;
      }
      // Also match just the year context
      if (/^(en|in)\s+facebook\s+desde\s+\d{4}/i.test(text)) {
        sellerJoinDate = text;
        break;
      }
    }

    // ============================================
    // IMAGES
    // ============================================
    const images = Array.from(document.querySelectorAll("img"));
    const listingImages = images.filter((img) => {
      const src = img.src || "";
      const width = img.naturalWidth || img.width;
      // Facebook CDN images that are reasonably sized
      return (src.includes("scontent") || src.includes("fbcdn")) && width > 100;
    });

    // Also count thumbnail images at bottom
    const thumbnails = document.querySelectorAll('[role="img"], [aria-label*="photo"], [aria-label*="foto"]');

    // ============================================
    // BUILD RESULT
    // ============================================
    const marketplaceData = {
      url: window.location.href,
      platform: "facebook_marketplace",
      screenshot_base64: screenshot,
      html_content: document.documentElement.outerHTML,

      listing: {
        title: title,
        price: price,
        description: description,
        condition: condition,
        location: listingLocation,
        posted_date: postedDate,
        category: null,
        image_count: Math.max(listingImages.length, thumbnails.length),
      },

      seller: {
        name: sellerName,
        profile_url: sellerProfileUrl,
        join_date: sellerJoinDate,
        location: listingLocation,
        rating: null,
        response_rate: null,
        other_listings_count: null,
      },

      listing_images: listingImages.slice(0, 5).map((img) => img.src),
      seller_other_listings: [],
    };

    console.log("[Page Analyzer] Marketplace data collected:", marketplaceData);
    return marketplaceData;
  }

  // Capture screenshot of the page
  async function captureScreenshot() {
    try {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      const width = Math.min(1280, window.innerWidth);
      const height = Math.min(720, window.innerHeight);

      canvas.width = width;
      canvas.height = height;

      // Use chrome.tabs.captureVisibleTab API through background script
      return new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "CAPTURE_SCREENSHOT" },
          (response) => {
            if (response && response.screenshot) {
              resolve(response.screenshot);
            } else {
              console.warn("[Page Analyzer] Screenshot capture failed");
              resolve(null);
            }
          }
        );
      });
    } catch (error) {
      console.error("[Page Analyzer] Screenshot error:", error);
      return null;
    }
  }

  // Get meta tag content
  function getMetaContent(name) {
    const meta =
      document.querySelector(`meta[name="${name}"]`) ||
      document.querySelector(`meta[property="og:${name}"]`);
    return meta ? meta.getAttribute("content") : "Not specified";
  }

  // Analyze links on the page
  function analyzeLinks() {
    const links = Array.from(document.getElementsByTagName("a"));
    const currentHost = window.location.hostname;

    let internal = 0;
    let external = 0;

    links.forEach((link) => {
      try {
        const href = link.href;
        if (!href || href.startsWith("javascript:") || href.startsWith("#"))
          return;
        const url = new URL(href);
        if (url.hostname === currentHost) {
          internal++;
        } else {
          external++;
        }
      } catch (e) {
        // Invalid URL, skip
      }
    });

    return { total: links.length, internal, external };
  }

  // Send data to backend for AI analysis
  async function analyzeWithAI(pageData, platform) {
    // Route to appropriate endpoint based on platform
    const endpoint = platform === "facebook_marketplace"
      ? `${API_URL}/analyze/marketplace`
      : `${API_URL}/analyze`;

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(pageData),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    return response.json();
  }

  // Render initial page info
  function renderPageInfo(info) {
    return `
      <div class="pa-section">
        <h3>General Information</h3>
        <div class="pa-item">
          <span class="pa-label">URL</span>
          <span class="pa-value pa-url">${escapeHtml(info.url)}</span>
        </div>
        <div class="pa-item">
          <span class="pa-label">Title</span>
          <span class="pa-value">${escapeHtml(info.title)}</span>
        </div>
        <div class="pa-item">
          <span class="pa-label">Protocol</span>
          <span class="pa-value">${escapeHtml(info.protocol)}</span>
        </div>
      </div>

      <div class="pa-section">
        <h3>Page Statistics</h3>
        <div class="pa-stats">
          <div class="pa-stat">
            <span class="pa-stat-value">${info.scripts}</span>
            <span class="pa-stat-label">Scripts</span>
          </div>
          <div class="pa-stat">
            <span class="pa-stat-value">${info.externalScripts}</span>
            <span class="pa-stat-label">External</span>
          </div>
          <div class="pa-stat">
            <span class="pa-stat-value">${info.links.total}</span>
            <span class="pa-stat-label">Links</span>
          </div>
        </div>
      </div>

      <div class="pa-section pa-ai-section">
        <button id="pa-analyze-btn" class="pa-analyze-btn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/>
            <path d="M2 17l10 5 10-5"/>
            <path d="M2 12l10 5 10-5"/>
          </svg>
          Analyze with AI
        </button>
      </div>

      <div id="pa-ai-results"></div>
    `;
  }

  // Render Facebook Marketplace info
  function renderMarketplaceInfo(data) {
    const listing = data.listing || {};
    const seller = data.seller || {};

    return `
      <div class="pa-section">
        <h3>Facebook Marketplace</h3>
        <div class="pa-marketplace-badge">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
            <polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
          <span>Listing Analysis</span>
        </div>
      </div>

      <div class="pa-section">
        <h3>Listing Details</h3>
        <div class="pa-item">
          <span class="pa-label">Title</span>
          <span class="pa-value">${escapeHtml(listing.title || "Not found")}</span>
        </div>
        <div class="pa-item">
          <span class="pa-label">Price</span>
          <span class="pa-value pa-price">${escapeHtml(listing.price || "Not found")}</span>
        </div>
        ${listing.condition ? `
        <div class="pa-item">
          <span class="pa-label">Condition</span>
          <span class="pa-value">${escapeHtml(listing.condition)}</span>
        </div>
        ` : ""}
        ${listing.posted_date ? `
        <div class="pa-item">
          <span class="pa-label">Posted</span>
          <span class="pa-value">${escapeHtml(listing.posted_date)}</span>
        </div>
        ` : ""}
        <div class="pa-item">
          <span class="pa-label">Images</span>
          <span class="pa-value">${listing.image_count || 0} photos</span>
        </div>
      </div>

      <div class="pa-section">
        <h3>Seller Info</h3>
        <div class="pa-item">
          <span class="pa-label">Name</span>
          <span class="pa-value">${escapeHtml(seller.name || "Not found")}</span>
        </div>
        ${seller.join_date ? `
        <div class="pa-item">
          <span class="pa-label">Account</span>
          <span class="pa-value">${escapeHtml(seller.join_date)}</span>
        </div>
        ` : ""}
        ${seller.location ? `
        <div class="pa-item">
          <span class="pa-label">Location</span>
          <span class="pa-value">${escapeHtml(seller.location)}</span>
        </div>
        ` : ""}
      </div>

      <div class="pa-section pa-ai-section">
        <button id="pa-analyze-btn" class="pa-analyze-btn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/>
            <path d="M2 17l10 5 10-5"/>
            <path d="M2 12l10 5 10-5"/>
          </svg>
          Analyze Listing Safety
        </button>
      </div>

      <div id="pa-ai-results"></div>
    `;
  }

  // Render AI analysis results
  function renderAIResults(analysis) {
    const riskColors = {
      safe: "#22c55e",
      suspicious: "#f59e0b",
      dangerous: "#ef4444",
    };

    const riskColor = riskColors[analysis.risk_level] || riskColors.suspicious;

    let html = `
      <div class="pa-section pa-risk-section" style="border-left: 4px solid ${riskColor};">
        <div class="pa-risk-header">
          <span class="pa-risk-badge" style="background: ${riskColor};">
            ${analysis.risk_level.toUpperCase()}
          </span>
          <span class="pa-score">Score: ${analysis.score}/100</span>
        </div>
        <h3 class="pa-verdict-title">${escapeHtml(analysis.verdict_title)}</h3>
        <p class="pa-summary">${escapeHtml(analysis.verdict_message)}</p>
      </div>
    `;

    // Render flags by type
    if (analysis.flags && analysis.flags.length > 0) {
      const criticalFlags = analysis.flags.filter((f) => f.type === "critical");
      const warningFlags = analysis.flags.filter((f) => f.type === "warning");
      const infoFlags = analysis.flags.filter((f) => f.type === "info");

      // Critical flags
      if (criticalFlags.length > 0) {
        html += `
          <div class="pa-section pa-flags-section">
            <h3 class="pa-flags-title pa-red">Critical Issues</h3>
            <ul class="pa-flags-list">
              ${criticalFlags
                .map(
                  (flag) => `
                <li class="pa-flag pa-flag-red">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                  </svg>
                  <span>${escapeHtml(flag.msg)}</span>
                </li>
              `
                )
                .join("")}
            </ul>
          </div>
        `;
      }

      // Warning flags
      if (warningFlags.length > 0) {
        html += `
          <div class="pa-section pa-flags-section">
            <h3 class="pa-flags-title pa-yellow">Warnings</h3>
            <ul class="pa-flags-list">
              ${warningFlags
                .map(
                  (flag) => `
                <li class="pa-flag pa-flag-yellow">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                  </svg>
                  <span>${escapeHtml(flag.msg)}</span>
                </li>
              `
                )
                .join("")}
            </ul>
          </div>
        `;
      }

      // Info flags
      if (infoFlags.length > 0) {
        html += `
          <div class="pa-section pa-flags-section">
            <h3 class="pa-flags-title pa-green">Information</h3>
            <ul class="pa-flags-list">
              ${infoFlags
                .map(
                  (flag) => `
                <li class="pa-flag pa-flag-green">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                  </svg>
                  <span>${escapeHtml(flag.msg)}</span>
                </li>
              `
                )
                .join("")}
            </ul>
          </div>
        `;
      }
    }

    // ============================================
    // DETAILED INFORMATION SECTIONS
    // ============================================
    const details = analysis.details || {};

    // Render seller details if available
    if (details.seller && Object.keys(details.seller).length > 0) {
      html += renderSellerDetails(details.seller);
    }

    // Render pricing details if available
    if (details.pricing && Object.keys(details.pricing).length > 0) {
      html += renderPricingDetails(details.pricing);
    }

    // Render image analysis details if available
    if (details.images && Object.keys(details.images).length > 0) {
      html += renderImageDetails(details.images);
    }

    // Render red flags details if available
    if (details.red_flags && Object.keys(details.red_flags).length > 0) {
      html += renderRedFlagsDetails(details.red_flags);
    }

    return html;
  }

  // Render detailed seller information
  function renderSellerDetails(seller) {
    let html = `
      <div class="pa-section pa-details-section">
        <h3 class="pa-section-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          Detalles del Vendedor
        </h3>
        <div class="pa-details-grid">
    `;

    // Seller name
    if (seller.seller_name) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Nombre</span>
          <span class="pa-detail-value">${escapeHtml(seller.seller_name)}</span>
        </div>
      `;
    }

    // Account age
    if (seller.account_age_years !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Antigüedad</span>
          <span class="pa-detail-value pa-detail-highlight">${seller.account_age_years} años</span>
        </div>
      `;
    }

    // Join year
    if (seller.join_year) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Miembro desde</span>
          <span class="pa-detail-value">${seller.join_year}</span>
        </div>
      `;
    }

    // Ratings average (stars)
    if (seller.ratings_average !== undefined) {
      const stars = '★'.repeat(Math.round(seller.ratings_average)) + '☆'.repeat(5 - Math.round(seller.ratings_average));
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Calificación</span>
          <span class="pa-detail-value">
            <span class="pa-stars-display">${stars}</span>
            <span class="pa-rating-number">${seller.ratings_average.toFixed(1)}</span>
          </span>
        </div>
      `;
    }

    // Ratings count
    if (seller.ratings_count !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Reseñas</span>
          <span class="pa-detail-value">${seller.ratings_count} calificaciones</span>
        </div>
      `;
    }

    // Followers
    if (seller.followers_count !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Seguidores</span>
          <span class="pa-detail-value">${seller.followers_count}</span>
        </div>
      `;
    }

    // Listings count
    if (seller.listings_count) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Publicaciones</span>
          <span class="pa-detail-value">${escapeHtml(seller.listings_count)}</span>
        </div>
      `;
    }

    // Other listings count (legacy)
    if (seller.other_listings_count !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Otras publicaciones</span>
          <span class="pa-detail-value">${seller.other_listings_count}</span>
        </div>
      `;
    }

    // Response rate
    if (seller.response_rate) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Respuesta</span>
          <span class="pa-detail-value">${escapeHtml(seller.response_rate)}</span>
        </div>
      `;
    }

    html += `</div>`; // Close grid

    // Badges (full width)
    if (seller.badges && seller.badges.length > 0) {
      html += `
        <div class="pa-detail-badges">
          <span class="pa-detail-label">Insignias</span>
          <div class="pa-badges-container">
            ${seller.badges.map(badge => `
              <span class="pa-badge-item">${escapeHtml(badge)}</span>
            `).join('')}
          </div>
        </div>
      `;
    }

    // Strengths (full width)
    if (seller.strengths && seller.strengths.length > 0) {
      html += `
        <div class="pa-detail-strengths">
          <span class="pa-detail-label">Fortalezas</span>
          <div class="pa-strengths-container">
            ${seller.strengths.map(strength => `
              <span class="pa-strength-item">${escapeHtml(strength)}</span>
            `).join('')}
          </div>
        </div>
      `;
    }

    // Profile investigated indicator
    if (seller.profile_investigated) {
      html += `
        <div class="pa-profile-investigated">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
          Perfil investigado en profundidad
        </div>
      `;
    }

    html += `</div>`; // Close section
    return html;
  }

  // Render pricing details
  function renderPricingDetails(pricing) {
    let html = `
      <div class="pa-section pa-details-section">
        <h3 class="pa-section-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="1" x2="12" y2="23"/>
            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
          </svg>
          Detalles del Precio
        </h3>
        <div class="pa-details-grid">
    `;

    // Raw price
    if (pricing.price_raw) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Precio publicado</span>
          <span class="pa-detail-value pa-price-display">${escapeHtml(pricing.price_raw)}</span>
        </div>
      `;
    }

    // Numeric price
    if (pricing.price_numeric !== undefined) {
      const formattedPrice = new Intl.NumberFormat('es-CL').format(pricing.price_numeric);
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Valor numérico</span>
          <span class="pa-detail-value">$${formattedPrice}</span>
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;
    return html;
  }

  // Render image analysis details
  function renderImageDetails(images) {
    let html = `
      <div class="pa-section pa-details-section">
        <h3 class="pa-section-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
            <circle cx="8.5" cy="8.5" r="1.5"/>
            <polyline points="21 15 16 10 5 21"/>
          </svg>
          Análisis de Imágenes
        </h3>
        <div class="pa-details-grid">
    `;

    // Image count
    if (images.image_count !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Cantidad</span>
          <span class="pa-detail-value">${images.image_count} ${images.image_count === 1 ? 'imagen' : 'imágenes'}</span>
        </div>
      `;
    }

    // Screenshot available
    html += `
      <div class="pa-detail-item">
        <span class="pa-detail-label">Screenshot</span>
        <span class="pa-detail-value">${images.screenshot_available ? '✓ Capturado' : '✗ No disponible'}</span>
      </div>
    `;

    html += `
        </div>
      </div>
    `;
    return html;
  }

  // Render red flags details
  function renderRedFlagsDetails(redFlags) {
    // Skip if no meaningful flags
    const hasData = Object.values(redFlags).some(v => v !== undefined && v !== null && v !== false);
    if (!hasData) return '';

    let html = `
      <div class="pa-section pa-details-section pa-red-flags-details">
        <h3 class="pa-section-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
            <line x1="4" y1="22" x2="4" y2="15"/>
          </svg>
          Datos de Alerta
        </h3>
        <div class="pa-details-grid">
    `;

    // Days posted
    if (redFlags.days_posted !== undefined) {
      html += `
        <div class="pa-detail-item">
          <span class="pa-detail-label">Días publicado</span>
          <span class="pa-detail-value">${redFlags.days_posted} ${redFlags.days_posted === 1 ? 'día' : 'días'}</span>
        </div>
      `;
    }

    // Location mismatch
    if (redFlags.location_mismatch) {
      html += `
        <div class="pa-detail-item pa-detail-warning">
          <span class="pa-detail-label">Ubicación</span>
          <span class="pa-detail-value">⚠️ No coincide</span>
        </div>
      `;
    }

    // Payment red flag
    if (redFlags.payment_red_flag) {
      html += `
        <div class="pa-detail-item pa-detail-danger">
          <span class="pa-detail-label">Pago sospechoso</span>
          <span class="pa-detail-value">🚨 ${escapeHtml(redFlags.payment_red_flag)}</span>
        </div>
      `;
    }

    // Contact bypass
    if (redFlags.contact_bypass) {
      html += `
        <div class="pa-detail-item pa-detail-warning">
          <span class="pa-detail-label">Contacto externo</span>
          <span class="pa-detail-value">⚠️ ${escapeHtml(redFlags.contact_bypass)}</span>
        </div>
      `;
    }

    // Phone in description
    if (redFlags.phone_in_description) {
      html += `
        <div class="pa-detail-item pa-detail-warning">
          <span class="pa-detail-label">Teléfono</span>
          <span class="pa-detail-value">⚠️ En descripción</span>
        </div>
      `;
    }

    // Email in description
    if (redFlags.email_in_description) {
      html += `
        <div class="pa-detail-item pa-detail-warning">
          <span class="pa-detail-label">Email</span>
          <span class="pa-detail-value">⚠️ En descripción</span>
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;
    return html;
  }

  // Render loading state
  function renderLoading() {
    return `
      <div class="pa-section pa-loading-section">
        <div class="pa-spinner"></div>
        <p>Analyzing page with AI...</p>
      </div>
    `;
  }

  // Render error state
  function renderError(message) {
    return `
      <div class="pa-section pa-error-section">
        <p class="pa-error">Analysis failed: ${escapeHtml(message)}</p>
        <button id="pa-retry-btn" class="pa-analyze-btn">Retry</button>
      </div>
    `;
  }

  // Escape HTML to prevent XSS
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Initialize
  function init() {
    const button = createButton();
    const panel = createSidePanel();
    const content = document.getElementById("pa-content");
    const closeBtn = document.getElementById("pa-close-btn");

    let isOpen = false;
    let pageData = null;
    let currentPlatform = detectPlatform();

    // Cache for persisting results
    let cachedUrl = null;
    let cachedAnalysis = null;
    let cachedContentHtml = null;

    // Toggle panel on button click
    button.addEventListener("click", async () => {
      isOpen = !isOpen;
      panel.classList.toggle("pa-open", isOpen);
      button.classList.toggle("pa-active", isOpen);

      // Hide button when panel is open
      button.style.display = isOpen ? "none" : "flex";

      if (isOpen) {
        // Re-detect platform in case user navigated
        currentPlatform = detectPlatform();
        const currentUrl = window.location.href;

        // Check if we have cached results for this URL
        if (cachedUrl === currentUrl && cachedContentHtml) {
          // Restore cached content
          content.innerHTML = cachedContentHtml;

          // Re-attach handlers if needed (for retry button, etc.)
          attachAnalyzeHandler(currentPlatform);
          return;
        }

        // New page or no cache - collect fresh data
        cachedUrl = currentUrl;
        cachedAnalysis = null;
        cachedContentHtml = null;

        content.innerHTML = '<p class="pa-loading">Loading page data...</p>';

        // Use appropriate data collector based on platform
        if (currentPlatform === "facebook_marketplace") {
          pageData = await collectMarketplaceData();
          content.innerHTML = renderMarketplaceInfo(pageData);
        } else {
          pageData = await collectPageData();
          content.innerHTML = renderPageInfo(pageData);
        }

        attachAnalyzeHandler(currentPlatform);
      }
    });

    // Attach AI analyze button handler
    function attachAnalyzeHandler(platform) {
      const analyzeBtn = document.getElementById("pa-analyze-btn");
      if (analyzeBtn) {
        analyzeBtn.addEventListener("click", () => handleAnalyze(platform));
      }
    }

    // Handle AI analysis
    async function handleAnalyze(platform) {
      const content = document.getElementById("pa-content");

      try {
        let dataToAnalyze;

        if (platform === "facebook_marketplace") {
          // Use deep investigation flow for Facebook Marketplace
          content.innerHTML = renderProgressUI(0);

          // Deep investigation with progress updates
          dataToAnalyze = await deepInvestigateMarketplace();

          // Update to final analysis step
          updateProgressStep(4);
        } else {
          // Regular flow for e-commerce
          content.innerHTML = renderLoading();
          dataToAnalyze = pageData;
        }

        // Send to backend for analysis
        const analysis = await analyzeWithAI(dataToAnalyze, platform);

        // Show results
        const resultsHtml = renderAIResults(analysis);
        content.innerHTML = resultsHtml;

        // Cache the results
        cachedAnalysis = analysis;
        cachedContentHtml = resultsHtml;

      } catch (error) {
        console.error('[BodyCart] Analysis error:', error);
        content.innerHTML = renderError(error.message);

        // Add retry button
        const retryBtn = document.getElementById("pa-retry-btn");
        if (retryBtn) {
          retryBtn.addEventListener("click", () => handleAnalyze(platform));
        }
      }
    }

    // Close panel helper
    function closePanel() {
      isOpen = false;
      panel.classList.remove("pa-open");
      button.classList.remove("pa-active");
      button.style.display = "flex"; // Show button again
    }

    // Close panel
    closeBtn.addEventListener("click", closePanel);

    // Close on Escape key
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && isOpen) {
        closePanel();
      }
    });
  }

  // Run when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
